//
//  OneViewController.m
//  bnb
//
//  Created by 谭 卓勋 on 16/9/9.
//  Copyright (c) 2016年 Tidus. All rights reserved.
//

#import "OneViewController.h"
#import "KCContact.h"
#import "KCContactGroup.h"

@interface OneViewController ()<UISearchDisplayDelegate,UISearchBarDelegate,UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate,UIAlertViewDelegate>
@property(strong,nonatomic)UITableView *tableView;
@property(strong,nonatomic)NSMutableArray *contacts;//联系人模型
@property (retain, nonatomic) NSMutableArray *images;
@property (retain, nonatomic) UIScrollView *scrollView;

@end

@implementation OneViewController
- (void)viewDidLoad {
    
    [super viewDidLoad];
    //创建一个分组样式的UITableView
    [self initData];
    _tableView=[[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    
    //设置数据源，注意必须实现对应的UITableViewDataSource协议
    _tableView.dataSource=self;
    self.tableView.rowHeight=88;
    UIImage *first=[UIImage imageNamed:@"103.png"];
    UIImage *second=[UIImage imageNamed:@"101.png"];
    UIImage *three=[UIImage imageNamed:@"102.png"];
    
    
    self.images = [[NSMutableArray alloc]initWithObjects:first,second,three, nil];
    [self.view addSubview:_tableView];

      

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark 加载数据
-(void)initData{
    _contacts=[[NSMutableArray alloc]init];
    
    KCContact *contact1=[KCContact initWithFirstName:@"Cui" andLastName:@"Kenshin" andPhoneNumber:@"18500131234"];
    KCContactGroup *group1=[KCContactGroup initWithName:@"C" andDetail:@"With names beginning with C" andContacts:[NSMutableArray arrayWithObjects:contact1, nil]];
    [_contacts addObject:group1];
    
    
    
    KCContact *contact2=[KCContact initWithFirstName:@"Lee" andLastName:@"Terry" andPhoneNumber:@"18500131238"];
    
    KCContactGroup *group2=[KCContactGroup initWithName:@"L" andDetail:@"With names beginning with L" andContacts:[NSMutableArray arrayWithObjects:contact2,nil]];
    [_contacts addObject:group2];
    
    
    
    KCContact *contact3=[KCContact initWithFirstName:@"Sun" andLastName:@"Kaoru" andPhoneNumber:@"18500131235"];
   
    
    KCContactGroup *group3=[KCContactGroup initWithName:@"S" andDetail:@"With names beginning with S" andContacts:[NSMutableArray arrayWithObjects:contact3, nil]];
    [_contacts addObject:group3];
    
    
  
    
}

#pragma mark - 数据源方法
#pragma mark 返回分组数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    NSLog(@"计算分组数");
    return _contacts.count;
}

#pragma mark 返回每组行数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    KCContactGroup *group1=_contacts[section];
    return group1.contacts.count;
}

#pragma mark返回每行的单元格
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //NSIndexPath是一个结构体，记录了组和行信息

    KCContactGroup *group=_contacts[indexPath.section];
    KCContact *contact=group.contacts[indexPath.row];
    UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    cell.textLabel.text=[contact getName];
    cell.detailTextLabel.text=contact.phoneNumber;
    NSInteger row = [indexPath row];  //关键点之一  cell的位置
    
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(130, 55*row, 150, 80)];
    scrollView.delegate = self;
    scrollView.backgroundColor=[UIColor blackColor];
    scrollView.pagingEnabled=YES;
    
    //当超出边界时表示是否可以反弹
    
    scrollView.bounces=YES;
    //是否滚动
    
    scrollView.scrollEnabled=YES;
    
    //将自己设置成.delegate
    scrollView.delegate=self;
    CGSize size=CGSizeMake(self.images.count*self.scrollView.frame.size.width, 70);
    
    //显示内容大小
    
    scrollView.contentSize=size;
    

    for(int i=0;i+1<4;i++){
        UIImageView *imageView=[[UIImageView alloc] initWithImage:self.images[i]];
        //图片显示形式
                imageView.contentMode=UIViewContentModeTop;
        //图片显示范围
        
        imageView.frame=CGRectMake((i+1)*55 ,55*row, self.scrollView.frame.size.width,80);
        
        //加到scrollView中
       

        
        [scrollView addSubview:imageView];
        
    }
    
    [cell.contentView addGestureRecognizer:self.scrollView.panGestureRecognizer];
    [cell.contentView addSubview:scrollView];
        return cell;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
